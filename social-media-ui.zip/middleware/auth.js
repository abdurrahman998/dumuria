import { auth } from "../config/firebase.js"
import User from "../models/User.js"
import { ApiError } from "../utils/ApiError.js"

// Verify Firebase token and attach user to request
export const verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new ApiError(401, "Unauthorized - No token provided")
    }

    const token = authHeader.split(" ")[1]

    // Verify the Firebase token
    const decodedToken = await auth.verifyIdToken(token)

    if (!decodedToken) {
      throw new ApiError(401, "Unauthorized - Invalid token")
    }

    // Find the user in our database
    const user = await User.findOne({ firebaseUid: decodedToken.uid })

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    if (!user.isActive) {
      throw new ApiError(403, "Account is deactivated")
    }

    // Update last seen
    user.lastSeen = new Date()
    await user.save()

    // Attach user to request object
    req.user = user
    req.firebaseUser = decodedToken

    next()
  } catch (error) {
    if (error instanceof ApiError) {
      next(error)
    } else {
      next(new ApiError(401, "Unauthorized - Authentication failed"))
    }
  }
}

// Check if user has required role
export const checkRole = (roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return next(new ApiError(401, "Unauthorized - Authentication required"))
    }

    if (!roles.includes(req.user.role)) {
      return next(new ApiError(403, "Forbidden - Insufficient permissions"))
    }

    next()
  }
}

// Admin only middleware
export const adminOnly = checkRole(["admin"])

// Moderator and admin middleware
export const moderatorAndAbove = checkRole(["moderator", "admin"])

