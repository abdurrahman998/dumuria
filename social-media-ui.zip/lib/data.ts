// This file contains mock data functions that would normally fetch from an API

// Mock user data
export const users = [
  {
    id: "user-1",
    name: "John Doe",
    username: "johndoe",
    avatar: "/placeholder.svg?height=40&width=40",
    coverImage: "/placeholder.svg?height=400&width=1200",
    bio: "Software developer and tech enthusiast. I love building web applications and exploring new technologies.",
    location: "San Francisco, CA",
    website: "https://example.com",
    joinedAt: "2020-01-01T00:00:00.000Z",
    following: 245,
    followers: 1024,
  },
  {
    id: "user-2",
    name: "Jane Smith",
    username: "janesmith",
    avatar: "/placeholder.svg?height=40&width=40",
    coverImage: "/placeholder.svg?height=400&width=1200",
    bio: "UX/UI Designer passionate about creating beautiful and functional interfaces.",
    location: "New York, NY",
    website: "https://janesmith.design",
    joinedAt: "2020-03-15T00:00:00.000Z",
    following: 178,
    followers: 892,
  },
  {
    id: "user-3",
    name: "Alex Johnson",
    username: "alexj",
    avatar: "/placeholder.svg?height=40&width=40",
    coverImage: "/placeholder.svg?height=400&width=1200",
    bio: "Product Manager | Tech Enthusiast | Coffee Lover",
    location: "Seattle, WA",
    website: "https://alexj.me",
    joinedAt: "2021-05-10T00:00:00.000Z",
    following: 312,
    followers: 567,
  },
]

// Mock post data
export const posts = [
  {
    id: "post-1",
    content: "Just launched my new portfolio website! Check it out and let me know what you think. #webdev #portfolio",
    image: "/placeholder.svg?height=400&width=600",
    createdAt: "2023-06-15T14:23:00.000Z",
    likes: 42,
    comments: 7,
    reposts: 5,
    views: 1024,
    author: users[0],
  },
  {
    id: "post-2",
    content: "Working on a new design system for our product. Excited to share more details soon!",
    createdAt: "2023-06-14T10:15:00.000Z",
    likes: 28,
    comments: 3,
    reposts: 2,
    views: 876,
    author: users[1],
  },
  {
    id: "post-3",
    content:
      "Just finished reading 'Atomic Habits' by James Clear. Highly recommend it if you're looking to build better habits and break bad ones.",
    image: "/placeholder.svg?height=400&width=600",
    createdAt: "2023-06-13T18:45:00.000Z",
    likes: 35,
    comments: 5,
    reposts: 8,
    views: 1245,
    author: users[2],
  },
  {
    id: "post-4",
    content:
      "Attended an amazing tech conference this weekend. Met so many talented developers and learned a lot about the latest trends in web development.",
    createdAt: "2023-06-12T09:30:00.000Z",
    likes: 19,
    comments: 2,
    reposts: 1,
    views: 732,
    author: users[0],
  },
  {
    id: "post-5",
    content:
      "Just pushed a major update to my open-source project. New features include dark mode, improved performance, and better accessibility. Check it out on GitHub!",
    createdAt: "2023-06-11T16:20:00.000Z",
    likes: 53,
    comments: 8,
    reposts: 12,
    views: 1567,
    author: users[0],
  },
]

// Mock conversations data
const conversations = [
  {
    id: "conversation-1",
    participant: users[1],
    lastMessage: {
      content: "Hey, how's the design system coming along?",
      timestamp: "2023-06-16T10:00:00.000Z",
    },
  },
  {
    id: "conversation-2",
    participant: users[2],
    lastMessage: {
      content: "I'm really enjoying 'Atomic Habits'! Thanks for the recommendation.",
      timestamp: "2023-06-15T18:00:00.000Z",
    },
  },
]

// Mock messages data
const messages = {
  "conversation-1": [
    {
      id: "message-1",
      content: "Hey, how's the design system coming along?",
      timestamp: "2023-06-16T10:00:00.000Z",
      senderId: "user-1",
      isRead: true,
    },
    {
      id: "message-2",
      content: "It's going well! Just finished the color palette and typography.",
      timestamp: "2023-06-16T10:05:00.000Z",
      senderId: "user-2",
      isRead: true,
    },
  ],
  "conversation-2": [
    {
      id: "message-3",
      content: "I'm really enjoying 'Atomic Habits'! Thanks for the recommendation.",
      timestamp: "2023-06-15T18:00:00.000Z",
      senderId: "user-1",
      isRead: true,
    },
    {
      id: "message-4",
      content: "Glad you like it! It's helped me a lot with productivity.",
      timestamp: "2023-06-15T18:05:00.000Z",
      senderId: "user-3",
      isRead: true,
    },
  ],
}

// Mock notifications data
const notifications = [
  {
    id: "notification-1",
    type: "like",
    actor: users[1],
    postId: "post-1",
    timestamp: "2023-06-16T12:00:00.000Z",
  },
  {
    id: "notification-2",
    type: "comment",
    actor: users[2],
    postId: "post-1",
    content: "Great job on the portfolio!",
    timestamp: "2023-06-16T12:30:00.000Z",
    isMention: true,
  },
  {
    id: "notification-3",
    type: "follow",
    actor: users[1],
    timestamp: "2023-06-16T13:00:00.000Z",
  },
]

// Mock saved posts data
const savedPosts = [posts[2], posts[4]]

// Mock analytics data
const analyticsData = {
  week: {
    profileViews: { total: 245, change: 12 },
    newFollowers: { total: 18, change: 5 },
    engagement: { total: 87, change: -3 },
    engagementData: [
      { date: "Mon", likes: 12, comments: 5, shares: 2 },
      { date: "Tue", likes: 18, comments: 8, shares: 3 },
      { date: "Wed", likes: 15, comments: 6, shares: 4 },
      { date: "Thu", likes: 22, comments: 10, shares: 5 },
      { date: "Fri", likes: 28, comments: 12, shares: 8 },
      { date: "Sat", likes: 20, comments: 9, shares: 6 },
      { date: "Sun", likes: 16, comments: 7, shares: 3 },
    ],
    topPosts: [
      { title: "Portfolio Launch", engagement: 54 },
      { title: "Open Source Update", engagement: 73 },
      { title: "Tech Conference", engagement: 22 },
    ],
  },
  month: {
    profileViews: { total: 1024, change: 28 },
    newFollowers: { total: 76, change: 15 },
    engagement: { total: 342, change: 8 },
    engagementData: [
      { date: "Week 1", likes: 65, comments: 28, shares: 12 },
      { date: "Week 2", likes: 78, comments: 35, shares: 18 },
      { date: "Week 3", likes: 92, comments: 42, shares: 24 },
      { date: "Week 4", likes: 107, comments: 48, shares: 30 },
    ],
    topPosts: [
      { title: "Portfolio Launch", engagement: 54 },
      { title: "Open Source Update", engagement: 73 },
      { title: "Tech Conference", engagement: 22 },
      { title: "Coding Tips", engagement: 45 },
      { title: "New Project", engagement: 38 },
    ],
  },
  year: {
    profileViews: { total: 12568, change: 142 },
    newFollowers: { total: 876, change: 32 },
    engagement: { total: 4532, change: 18 },
    engagementData: [
      { date: "Jan", likes: 245, comments: 112, shares: 54 },
      { date: "Feb", likes: 278, comments: 128, shares: 62 },
      { date: "Mar", likes: 312, comments: 145, shares: 78 },
      { date: "Apr", likes: 342, comments: 156, shares: 85 },
      { date: "May", likes: 378, comments: 172, shares: 92 },
      { date: "Jun", likes: 412, comments: 188, shares: 104 },
      { date: "Jul", likes: 445, comments: 202, shares: 118 },
      { date: "Aug", likes: 478, comments: 218, shares: 125 },
      { date: "Sep", likes: 512, comments: 232, shares: 138 },
      { date: "Oct", likes: 545, comments: 248, shares: 145 },
      { date: "Nov", likes: 578, comments: 262, shares: 152 },
      { date: "Dec", likes: 612, comments: 278, shares: 165 },
    ],
    topPosts: [
      { title: "Portfolio Launch", engagement: 254 },
      { title: "Open Source Update", engagement: 312 },
      { title: "Tech Conference", engagement: 178 },
      { title: "Coding Tips", engagement: 245 },
      { title: "New Project", engagement: 198 },
      { title: "Year in Review", engagement: 342 },
    ],
  },
}

// Mock data functions
export function getUserProfile(username: string) {
  return users.find((user) => user.username === username)
}

export function getPostById(id: string) {
  return posts.find((post) => post.id === id)
}

export async function getPosts(username?: string) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  if (username) {
    return posts.filter((post) => post.author.username === username)
  }

  return posts
}

export async function getComments(postId: string) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [] // Return empty array for now
}

export async function getSavedPosts() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return savedPosts
}

export async function getBookmarkedPosts() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Add collections to saved posts
  const enhancedSavedPosts = savedPosts.map((post) => ({
    ...post,
    collections: post.id === "post-2" ? ["Favorites"] : post.id === "post-3" ? ["Read Later", "Inspiration"] : [],
  }))

  return enhancedSavedPosts
}

export async function getUserAnalytics(timeframe = "week") {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return analyticsData[timeframe as keyof typeof analyticsData]
}

export async function getConversations() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return conversations
}

export async function getMessages(conversationId: string) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return messages[conversationId as keyof typeof messages] || []
}

export async function getNotifications() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Add isRead property to notifications
  const enhancedNotifications = notifications.map((notification, index) => ({
    ...notification,
    isRead: index > 1, // First two notifications are unread
  }))

  return enhancedNotifications
}

export function getConversationById(id: string) {
  return conversations.find((conversation) => conversation.id === id)
}

