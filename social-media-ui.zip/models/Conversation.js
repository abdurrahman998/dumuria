import mongoose from "mongoose"

const ConversationSchema = new mongoose.Schema(
  {
    participants: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
      },
    ],
    isGroup: {
      type: Boolean,
      default: false,
    },
    groupName: {
      type: String,
      trim: true,
      required: function () {
        return this.isGroup
      },
    },
    groupAdmin: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: function () {
        return this.isGroup
      },
    },
    groupImage: {
      type: String,
      default: "",
    },
    lastMessage: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Message",
    },
    unreadCounts: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        count: {
          type: Number,
          default: 0,
        },
      },
    ],
    pinnedBy: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    mutedBy: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        until: Date,
      },
    ],
  },
  { timestamps: true },
)

// Method to check if conversation is muted for a user
ConversationSchema.methods.isMutedForUser = function (userId) {
  const muteSetting = this.mutedBy.find((mute) => mute.user.toString() === userId.toString())
  if (!muteSetting) return false
  return muteSetting.until > new Date()
}

// Method to check if conversation is pinned by a user
ConversationSchema.methods.isPinnedByUser = function (userId) {
  return this.pinnedBy.some((id) => id.toString() === userId.toString())
}

// Method to get unread count for a user
ConversationSchema.methods.getUnreadCountForUser = function (userId) {
  const userCount = this.unreadCounts.find((item) => item.user.toString() === userId.toString())
  return userCount ? userCount.count : 0
}

// Virtual for conversation name (for direct messages)
ConversationSchema.virtual("name").get(function (userId) {
  if (this.isGroup) return this.groupName

  // This will be populated in the controller based on the requesting user
  return "Direct Message"
})

const Conversation = mongoose.model("Conversation", ConversationSchema)

export default Conversation

