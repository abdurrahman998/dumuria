import mongoose from "mongoose"

const CommentSchema = new mongoose.Schema(
  {
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Post",
      required: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    content: {
      type: String,
      required: true,
      maxlength: 1000,
    },
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    parentComment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Comment",
      default: null,
    },
    replies: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Comment",
      },
    ],
    isEdited: {
      type: Boolean,
      default: false,
    },
    mentions: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        startIndex: Number,
        endIndex: Number,
      },
    ],
    media: {
      type: {
        type: String,
        enum: ["image", "gif"],
      },
      url: String,
      alt: String,
    },
  },
  { timestamps: true },
)

// Virtual for comment's likes count
CommentSchema.virtual("likesCount").get(function () {
  return this.likes.length
})

// Virtual for comment's replies count
CommentSchema.virtual("repliesCount").get(function () {
  return this.replies.length
})

// Method to check if comment is a reply
CommentSchema.virtual("isReply").get(function () {
  return this.parentComment !== null
})

const Comment = mongoose.model("Comment", CommentSchema)

export default Comment

