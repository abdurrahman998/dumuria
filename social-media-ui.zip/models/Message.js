import mongoose from "mongoose"

const MessageSchema = new mongoose.Schema(
  {
    conversation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Conversation",
      required: true,
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    content: {
      type: String,
      required: function () {
        return !this.media && !this.voiceMessage
      },
      maxlength: 5000,
    },
    media: {
      type: {
        type: String,
        enum: ["image", "video", "gif", "file"],
      },
      url: String,
      fileName: String,
      fileSize: Number,
      mimeType: String,
    },
    voiceMessage: {
      url: String,
      duration: Number,
    },
    readBy: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        readAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    replyTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Message",
    },
    reactions: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        emoji: String,
      },
    ],
    isEdited: {
      type: Boolean,
      default: false,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
    expiresAt: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true },
)

// Virtual for message status
MessageSchema.virtual("status").get(function () {
  if (this.isDeleted) return "deleted"
  if (this.readBy.length > 0) return "read"
  return "delivered"
})

// Virtual for message type
MessageSchema.virtual("type").get(function () {
  if (this.media) return this.media.type
  if (this.voiceMessage) return "voice"
  return "text"
})

// Method to check if message has expired
MessageSchema.methods.hasExpired = function () {
  return this.expiresAt && new Date() > this.expiresAt
}

const Message = mongoose.model("Message", MessageSchema)

export default Message

