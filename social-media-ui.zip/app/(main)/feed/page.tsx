import type { Metadata } from "next"
import { PostFeed } from "@/components/post/post-feed"
import { CreatePostCard } from "@/components/post/create-post-card"
import { TrendingTopics } from "@/components/trending-topics"

export const metadata: Metadata = {
  title: "Feed | SocialSphere",
  description: "Your personalized social feed",
}

export default function FeedPage() {
  return (
    <div className="flex flex-col space-y-4 md:flex-row md:space-x-4 md:space-y-0">
      <div className="flex-1 space-y-4">
        <CreatePostCard />
        <PostFeed />
      </div>
      <div className="hidden w-80 flex-none space-y-4 lg:block">
        <TrendingTopics />
      </div>
    </div>
  )
}

