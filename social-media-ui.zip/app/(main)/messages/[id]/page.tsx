import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { MessageList } from "@/components/messages/message-list"
import { MessagePanel } from "@/components/messages/message-panel"
import { getConversationById } from "@/lib/data"

interface ConversationPageProps {
  params: {
    id: string
  }
}

export async function generateMetadata({ params }: ConversationPageProps): Promise<Metadata> {
  const conversation = getConversationById(params.id)

  if (!conversation) {
    return {
      title: "Conversation Not Found | SocialSphere",
    }
  }

  return {
    title: `Chat with ${conversation.participant.name} | SocialSphere`,
    description: "Your private conversation",
  }
}

// Update the layout to be responsive for mobile
export default function ConversationPage({ params }: ConversationPageProps) {
  const conversation = getConversationById(params.id)

  if (!conversation) {
    notFound()
  }

  return (
    <div className="flex h-[calc(100vh-3.5rem-1px)] flex-col md:flex-row">
      <MessageList className="hidden border-r md:block md:w-80" activeId={params.id} />
      <MessagePanel className="flex-1" conversation={conversation} />
    </div>
  )
}

