import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { verifyToken } from "../middleware/auth.js"
import {
  register,
  login,
  verifyOTP,
  resendOTP,
  logout,
  refreshToken,
  forgotPassword,
  resetPassword,
  changePassword,
} from "../controllers/authController.js"

const router = express.Router()

// Public routes
router.post("/register", asyncHandler(register))
router.post("/login", asyncHandler(login))
router.post("/verify-otp", asyncHandler(verifyOTP))
router.post("/resend-otp", asyncHandler(resendOTP))
router.post("/forgot-password", asyncHandler(forgotPassword))
router.post("/reset-password", asyncHandler(resetPassword))

// Protected routes
router.use(verifyToken)
router.post("/logout", asyncHandler(logout))
router.post("/refresh-token", asyncHandler(refreshToken))
router.post("/change-password", asyncHandler(changePassword))

export default router

