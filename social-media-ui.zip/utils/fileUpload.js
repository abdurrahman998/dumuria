import { storage } from "../config/firebase.js"
import { v4 as uuidv4 } from "uuid"
import { ApiError } from "./ApiError.js"
import sharp from "sharp"

// Allowed file types
const allowedImageTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
const allowedVideoTypes = ["video/mp4", "video/webm", "video/quicktime"]
const allowedAudioTypes = ["audio/mpeg", "audio/wav", "audio/ogg"]
const allowedFileTypes = [
  ...allowedImageTypes,
  ...allowedVideoTypes,
  ...allowedAudioTypes,
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
]

// Max file sizes (in bytes)
const MAX_IMAGE_SIZE = 5 * 1024 * 1024 // 5MB
const MAX_VIDEO_SIZE = 50 * 1024 * 1024 // 50MB
const MAX_AUDIO_SIZE = 10 * 1024 * 1024 // 10MB
const MAX_FILE_SIZE = 20 * 1024 * 1024 // 20MB

// Upload file to Firebase Storage
export const uploadFile = async (file, folder = "uploads") => {
  try {
    // Check if file exists
    if (!file || !file.buffer) {
      throw new ApiError(400, "No file provided")
    }

    // Check file type
    if (!allowedFileTypes.includes(file.mimetype)) {
      throw new ApiError(400, "File type not allowed")
    }

    // Check file size
    let maxSize = MAX_FILE_SIZE
    if (allowedImageTypes.includes(file.mimetype)) {
      maxSize = MAX_IMAGE_SIZE
    } else if (allowedVideoTypes.includes(file.mimetype)) {
      maxSize = MAX_VIDEO_SIZE
    } else if (allowedAudioTypes.includes(file.mimetype)) {
      maxSize = MAX_AUDIO_SIZE
    }

    if (file.size > maxSize) {
      throw new ApiError(400, `File too large. Maximum size is ${maxSize / (1024 * 1024)}MB`)
    }

    // Process image if it's an image
    let fileBuffer = file.buffer
    if (allowedImageTypes.includes(file.mimetype) && file.mimetype !== "image/gif") {
      // Resize and optimize image
      fileBuffer = await sharp(file.buffer)
        .resize(1200, 1200, { fit: "inside", withoutEnlargement: true })
        .jpeg({ quality: 80 })
        .toBuffer()
    }

    // Generate unique filename
    const fileExtension = file.originalname.split(".").pop()
    const fileName = `${uuidv4()}.${fileExtension}`
    const filePath = `${folder}/${fileName}`

    // Upload to Firebase Storage
    const bucket = storage.bucket()
    const fileRef = bucket.file(filePath)

    await fileRef.save(fileBuffer, {
      metadata: {
        contentType: file.mimetype,
      },
    })

    // Make file publicly accessible
    await fileRef.makePublic()

    // Get public URL
    const publicUrl = `https://storage.googleapis.com/${bucket.name}/${filePath}`

    return {
      url: publicUrl,
      fileName,
      fileSize: file.size,
      mimeType: file.mimetype,
    }
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error uploading file", [error.message])
  }
}

// Delete file from Firebase Storage
export const deleteFile = async (fileUrl) => {
  try {
    // Extract file path from URL
    const urlParts = fileUrl.split("/")
    const fileName = urlParts[urlParts.length - 1]
    const folderName = urlParts[urlParts.length - 2]
    const filePath = `${folderName}/${fileName}`

    // Delete from Firebase Storage
    const bucket = storage.bucket()
    const fileRef = bucket.file(filePath)

    await fileRef.delete()

    return true
  } catch (error) {
    console.error("Error deleting file:", error)
    return false
  }
}

