"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ThemeCustomizer } from "@/components/theme-customizer"
import { Bell, Home, Mail, Search, User, Bookmark } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { SearchBar } from "@/components/search/search-bar"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { getNotifications } from "@/lib/data"

export function MainNav() {
  const pathname = usePathname()
  const router = useRouter()
  const [unreadNotifications, setUnreadNotifications] = useState(0)
  const [unreadMessages, setUnreadMessages] = useState(0)

  useEffect(() => {
    // Fetch notification count
    const fetchNotificationCount = async () => {
      try {
        const notifications = await getNotifications()
        const unreadCount = notifications.filter((n: any) => !n.isRead).length
        setUnreadNotifications(unreadCount)
      } catch (error) {
        console.error("Error fetching notifications:", error)
      }
    }

    fetchNotificationCount()

    // Mock unread messages count
    setUnreadMessages(3)

    // Reset notification count when visiting notifications page
    if (pathname === "/notifications") {
      setUnreadNotifications(0)
    }

    // Reset messages count when visiting messages page
    if (pathname.startsWith("/messages")) {
      setUnreadMessages(0)
    }
  }, [pathname])

  const handleSearch = (query: string) => {
    router.push(`/search?q=${encodeURIComponent(query)}`)
  }

  return (
    <div className="mr-4 flex items-center space-x-4 lg:space-x-6">
      <Link href="/" className="flex items-center space-x-2">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="h-6 w-6 text-primary"
        >
          <path d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3" />
        </svg>
        <span className="hidden font-bold sm:inline-block">SocialSphere</span>
      </Link>
      <nav className="flex items-center space-x-2">
        <Link href="/feed">
          <Button variant="ghost" size="icon" className={cn("rounded-full", pathname === "/feed" && "bg-accent")}>
            <Home className="h-5 w-5" />
            <span className="sr-only">Home</span>
          </Button>
        </Link>
        <Link href="/search">
          <Button variant="ghost" size="icon" className={cn("rounded-full", pathname === "/search" && "bg-accent")}>
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
        </Link>
        <Link href="/notifications">
          <Button
            variant="ghost"
            size="icon"
            className={cn("rounded-full relative", pathname === "/notifications" && "bg-accent")}
          >
            <Bell className="h-5 w-5" />
            {unreadNotifications > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                {unreadNotifications > 9 ? "9+" : unreadNotifications}
              </span>
            )}
            <span className="sr-only">Notifications</span>
          </Button>
        </Link>
        <Link href="/messages">
          <Button
            variant="ghost"
            size="icon"
            className={cn("rounded-full relative", pathname.startsWith("/messages") && "bg-accent")}
          >
            <Mail className="h-5 w-5" />
            {unreadMessages > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                {unreadMessages > 9 ? "9+" : unreadMessages}
              </span>
            )}
            <span className="sr-only">Messages</span>
          </Button>
        </Link>
        <Link href="/bookmarks">
          <Button variant="ghost" size="icon" className={cn("rounded-full", pathname === "/bookmarks" && "bg-accent")}>
            <Bookmark className="h-5 w-5" />
            <span className="sr-only">Bookmarks</span>
          </Button>
        </Link>
      </nav>
      <div className="hidden flex-1 md:block">
        <SearchBar
          variant="command"
          onSearch={handleSearch}
          placeholder="Search..."
          className="w-full max-w-[500px] mx-auto"
        />
      </div>
      <div className="ml-auto flex items-center space-x-4">
        <ThemeCustomizer />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" alt="@user" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <span className="sr-only">User menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/profile/johndoe">
                <User className="mr-2 h-4 w-4" />
                Profile
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/bookmarks">
                <Bookmark className="mr-2 h-4 w-4" />
                Bookmarks
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/settings">Settings</Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/login">Sign out</Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}

