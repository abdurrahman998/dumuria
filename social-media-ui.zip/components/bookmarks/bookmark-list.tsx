"use client"

import { useState, useEffect } from "react"
import { PostCard } from "@/components/post/post-card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { Search, Bookmark, FolderPlus } from "lucide-react"
import { getBookmarkedPosts } from "@/lib/data"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

export function BookmarkList() {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [collections, setCollections] = useState<string[]>(["All", "Favorites", "Read Later", "Inspiration"])
  const [activeCollection, setActiveCollection] = useState("All")
  const [newCollectionName, setNewCollectionName] = useState("")
  const [isCreatingCollection, setIsCreatingCollection] = useState(false)

  useEffect(() => {
    const fetchBookmarkedPosts = async () => {
      setLoading(true)
      try {
        const data = await getBookmarkedPosts()
        setPosts(data)
      } catch (error) {
        console.error("Error fetching bookmarked posts:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchBookmarkedPosts()
  }, [])

  const filteredPosts = posts.filter((post) => {
    // Filter by search query
    const matchesSearch =
      searchQuery === "" ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.username.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by collection
    const matchesCollection = activeCollection === "All" || post.collections?.includes(activeCollection)

    return matchesSearch && matchesCollection
  })

  const handleCreateCollection = () => {
    if (newCollectionName.trim() && !collections.includes(newCollectionName)) {
      setCollections([...collections, newCollectionName])
      setNewCollectionName("")
      setIsCreatingCollection(false)
    }
  }

  const handleRemoveFromBookmarks = (postId: string) => {
    setPosts(posts.filter((post) => post.id !== postId))
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="rounded-lg border p-4">
            <div className="flex items-center space-x-4">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-[250px]" />
                <Skeleton className="h-4 w-[200px]" />
              </div>
            </div>
            <div className="mt-4 space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search bookmarks"
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Dialog open={isCreatingCollection} onOpenChange={setIsCreatingCollection}>
          <DialogTrigger asChild>
            <Button variant="outline" size="icon">
              <FolderPlus className="h-4 w-4" />
              <span className="sr-only">Create collection</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Collection</DialogTitle>
              <DialogDescription>Create a new collection to organize your bookmarks.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="collection-name">Collection Name</Label>
                <Input
                  id="collection-name"
                  placeholder="e.g., Travel Ideas, Work Resources"
                  value={newCollectionName}
                  onChange={(e) => setNewCollectionName(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreatingCollection(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateCollection} disabled={!newCollectionName.trim()}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="All" value={activeCollection} onValueChange={setActiveCollection}>
        <div className="overflow-x-auto pb-2">
          <TabsList className="inline-flex w-auto">
            {collections.map((collection) => (
              <TabsTrigger key={collection} value={collection} className="min-w-max">
                {collection === "All" ? <Bookmark className="mr-2 h-4 w-4" /> : null}
                {collection}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {collections.map((collection) => (
          <TabsContent key={collection} value={collection} className="space-y-4">
            {filteredPosts.length === 0 ? (
              <div className="rounded-lg border p-8 text-center">
                <Bookmark className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">No bookmarks found</h3>
                <p className="mt-2 text-muted-foreground">
                  {searchQuery ? "Try a different search term." : "Save posts to see them here."}
                </p>
                <Button className="mt-4" variant="outline" asChild>
                  <a href="/feed">Browse Feed</a>
                </Button>
              </div>
            ) : (
              filteredPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  isBookmarked={true}
                  onRemoveBookmark={() => handleRemoveFromBookmarks(post.id)}
                  collections={collections.filter((c) => c !== "All")}
                />
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

