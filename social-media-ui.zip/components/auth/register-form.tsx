"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Icons } from "@/components/icons"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { CalendarIcon } from "lucide-react"
import { Progress } from "@/components/ui/progress"

// Define the form schema for each step
const personalInfoSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  username: z
    .string()
    .min(3, { message: "Username must be at least 3 characters" })
    .regex(/^[a-zA-Z0-9_]+$/, { message: "Username can only contain letters, numbers, and underscores" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
})

const passwordSchema = z
  .object({
    password: z.string().min(8, { message: "Password must be at least 8 characters" }),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  })

const birthdaySchema = z.object({
  birthday: z
    .date({
      required_error: "Please select your date of birth",
    })
    .refine(
      (date) => {
        const today = new Date()
        const age = today.getFullYear() - date.getFullYear()
        const monthDiff = today.getMonth() - date.getMonth()
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < date.getDate())) {
          return age - 1 >= 13
        }
        return age >= 13
      },
      { message: "You must be at least 13 years old to register" },
    ),
})

const otpSchema = z.object({
  otp: z
    .string()
    .length(6, { message: "OTP must be 6 digits" })
    .regex(/^\d+$/, { message: "OTP must contain only numbers" }),
})

// Combine all schemas for the final form data
const formSchema = personalInfoSchema.merge(passwordSchema).merge(birthdaySchema).merge(otpSchema)

export function RegisterForm() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [progress, setProgress] = useState(25)
  const [otpSent, setOtpSent] = useState(false)
  const [otpError, setOtpError] = useState("")
  const [resendDisabled, setResendDisabled] = useState(false)
  const [countdown, setCountdown] = useState(60)

  // Create separate forms for each step
  const personalInfoForm = useForm<z.infer<typeof personalInfoSchema>>({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      name: "",
      username: "",
      email: "",
    },
  })

  const passwordForm = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  })

  const birthdayForm = useForm<z.infer<typeof birthdaySchema>>({
    resolver: zodResolver(birthdaySchema),
    defaultValues: {
      birthday: undefined,
    },
  })

  const otpForm = useForm<z.infer<typeof otpSchema>>({
    resolver: zodResolver(otpSchema),
    defaultValues: {
      otp: "",
    },
  })

  // Simulated OTP for demo purposes
  const correctOtp = "123456"

  // Handle countdown for OTP resend
  useEffect(() => {
    let timer: NodeJS.Timeout
    if (resendDisabled && countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000)
    } else if (countdown === 0) {
      setResendDisabled(false)
      setCountdown(60)
    }
    return () => clearTimeout(timer)
  }, [resendDisabled, countdown])

  // Handle step navigation
  const nextStep = () => {
    setCurrentStep(currentStep + 1)
    setProgress((currentStep + 1) * 25)
  }

  const prevStep = () => {
    setCurrentStep(currentStep - 1)
    setProgress((currentStep - 1) * 25)
  }

  // Handle form submissions for each step
  const onSubmitPersonalInfo = (data: z.infer<typeof personalInfoSchema>) => {
    nextStep()
  }

  const onSubmitPassword = (data: z.infer<typeof passwordSchema>) => {
    nextStep()
  }

  const onSubmitBirthday = (data: z.infer<typeof birthdaySchema>) => {
    // Simulate sending OTP
    setOtpSent(true)
    setResendDisabled(true)
    nextStep()
  }

  const onSubmitOtp = (data: z.infer<typeof otpSchema>) => {
    setIsLoading(true)

    // Validate OTP
    if (data.otp === correctOtp) {
      // Combine all form data
      const formData = {
        ...personalInfoForm.getValues(),
        ...passwordForm.getValues(),
        ...birthdayForm.getValues(),
        ...data,
      }

      // Simulate API call
      setTimeout(() => {
        setIsLoading(false)
        router.push("/feed")
      }, 1000)
    } else {
      setOtpError("Invalid verification code. Please try again.")
      setIsLoading(false)
    }
  }

  // Handle OTP resend
  const handleResendOtp = () => {
    setResendDisabled(true)
    setOtpError("")
    // Simulate resending OTP
    setTimeout(() => {
      setOtpSent(true)
    }, 500)
  }

  // Render the current step
  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Form {...personalInfoForm}>
            <form onSubmit={personalInfoForm.handleSubmit(onSubmitPersonalInfo)} className="space-y-4">
              <FormField
                control={personalInfoForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={personalInfoForm.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="johndoe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={personalInfoForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="name@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full">
                Continue
              </Button>
            </form>
          </Form>
        )
      case 2:
        return (
          <Form {...passwordForm}>
            <form onSubmit={passwordForm.handleSubmit(onSubmitPassword)} className="space-y-4">
              <FormField
                control={passwordForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={passwordForm.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={prevStep} className="w-1/2">
                  Back
                </Button>
                <Button type="submit" className="w-1/2">
                  Continue
                </Button>
              </div>
            </form>
          </Form>
        )
      case 3:
        return (
          <Form {...birthdayForm}>
            <form onSubmit={birthdayForm.handleSubmit(onSubmitBirthday)} className="space-y-4">
              <FormField
                control={birthdayForm.control}
                name="birthday"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date of Birth</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn("w-full pl-3 text-left font-normal", !field.value && "text-muted-foreground")}
                          >
                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => {
                            const today = new Date()
                            // Disable future dates and dates less than 13 years ago
                            const minDate = new Date()
                            minDate.setFullYear(today.getFullYear() - 100)
                            const maxDate = new Date()
                            maxDate.setFullYear(today.getFullYear() - 13)
                            return date > today || date < minDate || date > maxDate
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={prevStep} className="w-1/2">
                  Back
                </Button>
                <Button type="submit" className="w-1/2">
                  Continue
                </Button>
              </div>
            </form>
          </Form>
        )
      case 4:
        return (
          <Form {...otpForm}>
            <form onSubmit={otpForm.handleSubmit(onSubmitOtp)} className="space-y-4">
              <div className="text-center mb-4">
                <h3 className="text-lg font-medium">Verify Your Email</h3>
                <p className="text-sm text-muted-foreground">
                  We've sent a 6-digit verification code to {personalInfoForm.getValues().email}
                </p>
              </div>
              <FormField
                control={otpForm.control}
                name="otp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Code</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="123456"
                        {...field}
                        maxLength={6}
                        onChange={(e) => {
                          field.onChange(e)
                          setOtpError("")
                        }}
                      />
                    </FormControl>
                    {otpError && <p className="text-sm font-medium text-destructive">{otpError}</p>}
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="text-center">
                <Button
                  type="button"
                  variant="link"
                  className="text-xs"
                  onClick={handleResendOtp}
                  disabled={resendDisabled}
                >
                  {resendDisabled ? `Resend code in ${countdown}s` : "Didn't receive a code? Resend"}
                </Button>
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={prevStep} className="w-1/2">
                  Back
                </Button>
                <Button type="submit" className="w-1/2" disabled={isLoading}>
                  {isLoading && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
                  Create Account
                </Button>
              </div>
            </form>
          </Form>
        )
      default:
        return null
    }
  }

  return (
    <div className="grid gap-6">
      <div className="space-y-2">
        <Progress value={progress} className="h-2" />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Step {currentStep} of 4</span>
          <span>{progress}% Complete</span>
        </div>
      </div>

      {renderStep()}

      {currentStep === 4 && (
        <>
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" disabled={isLoading}>
              <Icons.google className="mr-2 h-4 w-4" />
              Google
            </Button>
            <Button variant="outline" disabled={isLoading}>
              <Icons.facebook className="mr-2 h-4 w-4" />
              Facebook
            </Button>
          </div>
        </>
      )}
    </div>
  )
}

