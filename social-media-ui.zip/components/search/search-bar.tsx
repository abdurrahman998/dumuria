"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Search, X, Mic, User, FileText, Hash, Users, Calendar, ChevronDown, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"
import { getSuggestions } from "@/lib/search"

interface SearchBarProps {
  initialQuery?: string
  onSearch?: (query: string) => void
  showVoiceSearch?: boolean
  showCategories?: boolean
  className?: string
  placeholder?: string
  autoFocus?: boolean
  variant?: "default" | "command"
}

// Declare the variable before using it
declare global {
  interface Window {
    webkitSpeechRecognition: any
  }
}

export function SearchBar({
  initialQuery = "",
  onSearch,
  showVoiceSearch = false,
  showCategories = false,
  className,
  placeholder = "Search for people, posts, hashtags...",
  autoFocus = false,
  variant = "default",
}: SearchBarProps) {
  const [query, setQuery] = useState(initialQuery)
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [isListening, setIsListening] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("all")
  const inputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query.trim()) {
        fetchSuggestions()
      } else {
        setSuggestions([])
      }
    }, 300)

    return () => clearTimeout(timer)
  }, [query])

  // Handle click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (inputRef.current && !inputRef.current.contains(event.target as Node)) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const fetchSuggestions = async () => {
    try {
      const results = await getSuggestions(query)
      setSuggestions(results)
    } catch (error) {
      console.error("Error fetching suggestions:", error)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value)
    if (e.target.value.trim()) {
      setShowSuggestions(true)
    } else {
      setShowSuggestions(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowSuggestions(false)

    if (onSearch) {
      onSearch(query)
    } else {
      router.push(`/search?q=${encodeURIComponent(query)}`)
    }
  }

  const handleClear = () => {
    setQuery("")
    setSuggestions([])
    setShowSuggestions(false)
    if (inputRef.current) {
      inputRef.current.focus()
    }

    if (onSearch) {
      onSearch("")
    }
  }

  const handleSuggestionClick = (suggestion: any) => {
    setShowSuggestions(false)

    if (suggestion.type === "user") {
      router.push(`/profile/${suggestion.username}`)
    } else if (suggestion.type === "hashtag") {
      if (onSearch) {
        onSearch(suggestion.name)
      } else {
        router.push(`/search?q=${encodeURIComponent(suggestion.name)}&category=hashtags`)
      }
    } else if (suggestion.type === "post") {
      router.push(`/post/${suggestion.id}`)
    } else {
      if (onSearch) {
        onSearch(suggestion.name || suggestion.content)
      } else {
        router.push(`/search?q=${encodeURIComponent(suggestion.name || suggestion.content)}`)
      }
    }
  }

  const handleVoiceSearch = () => {
    if (!("webkitSpeechRecognition" in window)) {
      alert("Voice search is not supported in your browser.")
      return
    }

    setIsListening(true)

    // @ts-ignore - WebkitSpeechRecognition is not in the TypeScript types
    const recognition = new window.webkitSpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript
      setQuery(transcript)
      setIsListening(false)

      if (onSearch) {
        onSearch(transcript)
      } else {
        router.push(`/search?q=${encodeURIComponent(transcript)}`)
      }
    }

    recognition.onerror = () => {
      setIsListening(false)
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognition.start()
  }

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category)

    if (query && onSearch) {
      onSearch(query)
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "users":
        return <User className="h-4 w-4" />
      case "posts":
        return <FileText className="h-4 w-4" />
      case "hashtags":
        return <Hash className="h-4 w-4" />
      case "groups":
        return <Users className="h-4 w-4" />
      case "events":
        return <Calendar className="h-4 w-4" />
      default:
        return <Search className="h-4 w-4" />
    }
  }

  if (variant === "command") {
    return (
      <Command className={cn("rounded-lg border shadow-md", className)}>
        <div className="flex items-center border-b px-3">
          <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
          <CommandInput
            ref={inputRef}
            value={query}
            onValueChange={setQuery}
            placeholder={placeholder}
            className="flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
            autoFocus={autoFocus}
          />
          {query && (
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0 rounded-full" onClick={handleClear}>
              <X className="h-4 w-4" />
              <span className="sr-only">Clear search</span>
            </Button>
          )}
          {showVoiceSearch && (
            <Button
              variant="ghost"
              size="sm"
              className={cn("ml-1 h-6 w-6 p-0 rounded-full", isListening && "text-red-500")}
              onClick={handleVoiceSearch}
              disabled={isListening}
            >
              <Mic className="h-4 w-4" />
              <span className="sr-only">Voice search</span>
            </Button>
          )}
        </div>
        <CommandList>
          {suggestions.length > 0 ? (
            <>
              <CommandGroup heading="People">
                {suggestions
                  .filter((s) => s.type === "user")
                  .slice(0, 3)
                  .map((suggestion) => (
                    <CommandItem
                      key={suggestion.id}
                      onSelect={() => handleSuggestionClick(suggestion)}
                      className="cursor-pointer"
                    >
                      <User className="mr-2 h-4 w-4" />
                      <span>{suggestion.name}</span>
                    </CommandItem>
                  ))}
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup heading="Hashtags">
                {suggestions
                  .filter((s) => s.type === "hashtag")
                  .slice(0, 3)
                  .map((suggestion) => (
                    <CommandItem
                      key={suggestion.id}
                      onSelect={() => handleSuggestionClick(suggestion)}
                      className="cursor-pointer"
                    >
                      <Hash className="mr-2 h-4 w-4" />
                      <span>{suggestion.name}</span>
                    </CommandItem>
                  ))}
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup heading="Posts">
                {suggestions
                  .filter((s) => s.type === "post")
                  .slice(0, 3)
                  .map((suggestion) => (
                    <CommandItem
                      key={suggestion.id}
                      onSelect={() => handleSuggestionClick(suggestion)}
                      className="cursor-pointer"
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      <span className="truncate">{suggestion.content}</span>
                    </CommandItem>
                  ))}
              </CommandGroup>
              <CommandSeparator />
              <CommandItem
                onSelect={() => {
                  if (onSearch) {
                    onSearch(query)
                  } else {
                    router.push(`/search?q=${encodeURIComponent(query)}`)
                  }
                }}
                className="cursor-pointer justify-center text-center"
              >
                <Search className="mr-2 h-4 w-4" />
                <span>Search for "{query}"</span>
              </CommandItem>
            </>
          ) : query ? (
            <CommandEmpty>No results found.</CommandEmpty>
          ) : null}
        </CommandList>
      </Command>
    )
  }

  return (
    <div className={cn("relative", className)} ref={inputRef}>
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative flex items-center">
          {showCategories && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute left-2 z-10 h-8 gap-1 rounded-full px-2 text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                >
                  {getCategoryIcon(selectedCategory)}
                  <span className="hidden sm:inline-block capitalize">
                    {selectedCategory === "all" ? "All" : selectedCategory}
                  </span>
                  <ChevronDown className="h-3 w-3 opacity-50" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => handleCategorySelect("all")}>
                  <Search className="mr-2 h-4 w-4" />
                  <span>All</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleCategorySelect("users")}>
                  <User className="mr-2 h-4 w-4" />
                  <span>People</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleCategorySelect("posts")}>
                  <FileText className="mr-2 h-4 w-4" />
                  <span>Posts</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleCategorySelect("hashtags")}>
                  <Hash className="mr-2 h-4 w-4" />
                  <span>Hashtags</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleCategorySelect("groups")}>
                  <Users className="mr-2 h-4 w-4" />
                  <span>Groups</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleCategorySelect("events")}>
                  <Calendar className="mr-2 h-4 w-4" />
                  <span>Events</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          <div className="relative flex-1">
            <Input
              ref={inputRef}
              type="search"
              placeholder={placeholder}
              value={query}
              onChange={handleInputChange}
              className={cn("pr-10", showCategories && "pl-[4.5rem] sm:pl-24")}
              autoFocus={autoFocus}
            />

            {query && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-10 top-1/2 h-6 w-6 -translate-y-1/2 p-0 rounded-full"
                onClick={handleClear}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Clear search</span>
              </Button>
            )}

            <Button
              type="submit"
              variant="ghost"
              size="sm"
              className="absolute right-1 top-1/2 h-8 w-8 -translate-y-1/2 p-0 rounded-full"
            >
              <Search className="h-4 w-4" />
              <span className="sr-only">Search</span>
            </Button>
          </div>

          {showVoiceSearch && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className={cn("ml-2 h-9 w-9 p-0 rounded-full", isListening && "text-red-500")}
              onClick={handleVoiceSearch}
              disabled={isListening}
            >
              <Mic className="h-5 w-5" />
              <span className="sr-only">Voice search</span>
            </Button>
          )}

          {showCategories && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="ml-2 h-9 w-9 p-0 rounded-full"
              onClick={() => {
                if (onSearch) {
                  onSearch(`${query} AI:recommend`)
                } else {
                  router.push(`/search?q=${encodeURIComponent(query)}&ai=true`)
                }
              }}
              title="AI-powered recommendations"
            >
              <Sparkles className="h-5 w-5 text-purple-500" />
              <span className="sr-only">AI Recommendations</span>
            </Button>
          )}
        </div>
      </form>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute left-0 right-0 top-full z-50 mt-1 overflow-hidden rounded-md border bg-popover shadow-md animate-in fade-in-0 zoom-in-95">
          <div className="p-1">
            {suggestions.length > 0 && <div className="p-2 text-xs font-medium text-muted-foreground">Suggestions</div>}

            {suggestions.slice(0, 6).map((suggestion) => (
              <button
                key={suggestion.id}
                className="flex w-full items-center rounded-sm px-2 py-1.5 text-sm hover:bg-accent hover:text-accent-foreground"
                onClick={() => handleSuggestionClick(suggestion)}
              >
                {suggestion.type === "user" && (
                  <>
                    <User className="mr-2 h-4 w-4" />
                    <span>{suggestion.name}</span>
                    <span className="ml-1 text-muted-foreground">@{suggestion.username}</span>
                  </>
                )}
                {suggestion.type === "hashtag" && (
                  <>
                    <Hash className="mr-2 h-4 w-4" />
                    <span>{suggestion.name}</span>
                  </>
                )}
                {suggestion.type === "post" && (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    <span className="truncate">{suggestion.content}</span>
                  </>
                )}
                {suggestion.type === "group" && (
                  <>
                    <Users className="mr-2 h-4 w-4" />
                    <span>{suggestion.name}</span>
                  </>
                )}
              </button>
            ))}

            <button
              className="flex w-full items-center justify-center rounded-sm px-2 py-1.5 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
              onClick={handleSubmit}
            >
              <Search className="mr-2 h-4 w-4" />
              <span>Search for "{query}"</span>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

