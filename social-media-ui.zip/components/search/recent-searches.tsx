"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, X } from "lucide-react"

interface RecentSearchesProps {
  searches: string[]
  onSearchClick: (query: string) => void
  onClearSearch: (query: string) => void
  onClearAll: () => void
}

export function RecentSearches({ searches, onSearchClick, onClearSearch, onClearAll }: RecentSearchesProps) {
  if (searches.length === 0) {
    return null
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg">Recent Searches</CardTitle>
        <Button variant="ghost" size="sm" onClick={onClearAll}>
          Clear all
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {searches.map((search, index) => (
            <div key={index} className="flex items-center justify-between rounded-md px-2 py-1.5 hover:bg-muted">
              <button className="flex items-center text-sm" onClick={() => onSearchClick(search)}>
                <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                {search}
              </button>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 rounded-full"
                onClick={() => onClearSearch(search)}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Remove</span>
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

