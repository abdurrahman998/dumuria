"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { formatDistanceToNow } from "date-fns"
import { Heart, Reply, ChevronDown, ChevronUp, MoreHorizontal } from "lucide-react"
import { Icons } from "@/components/icons"
import { getComments } from "@/lib/data"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

interface CommentSectionProps {
  postId: string
}

interface CommentType {
  id: string
  content: string
  createdAt: string
  author: {
    id: string
    name: string
    username: string
    avatar: string
  }
  likes: number
  replies: CommentType[]
  isLiked?: boolean
  parentId?: string | null
}

export function CommentSection({ postId }: CommentSectionProps) {
  const [comments, setComments] = useState<CommentType[]>([])
  const [loading, setLoading] = useState(true)
  const [commentText, setCommentText] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [replyingTo, setReplyingTo] = useState<string | null>(null)
  const [replyText, setReplyText] = useState("")
  const [expandedComments, setExpandedComments] = useState<string[]>([])
  const [sortBy, setSortBy] = useState<"recent" | "popular">("recent")

  useEffect(() => {
    const fetchComments = async () => {
      setLoading(true)
      try {
        const data = await getComments(postId)
        // Transform flat comments into nested structure
        const commentMap = new Map()
        const rootComments: CommentType[] = []

        // First pass: Create all comment objects
        data.forEach((comment: any) => {
          commentMap.set(comment.id, {
            ...comment,
            replies: [],
            isLiked: false,
          })
        })

        // Second pass: Establish parent-child relationships
        data.forEach((comment: any) => {
          const commentObj = commentMap.get(comment.id)
          if (comment.parentId) {
            const parentComment = commentMap.get(comment.parentId)
            if (parentComment) {
              parentComment.replies.push(commentObj)
            }
          } else {
            rootComments.push(commentObj)
          }
        })

        setComments(sortComments(rootComments, sortBy))
      } catch (error) {
        console.error("Error fetching comments:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchComments()
  }, [postId])

  const sortComments = (commentsToSort: CommentType[], sortType: "recent" | "popular") => {
    if (sortType === "recent") {
      return [...commentsToSort].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    } else {
      return [...commentsToSort].sort((a, b) => b.likes - a.likes)
    }
  }

  const handleSortChange = (newSortBy: "recent" | "popular") => {
    setSortBy(newSortBy)
    setComments(sortComments(comments, newSortBy))
  }

  const handleSubmit = async () => {
    if (!commentText.trim()) return

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      const newComment = {
        id: `comment-${Date.now()}`,
        content: commentText,
        createdAt: new Date().toISOString(),
        author: {
          id: "user-1",
          name: "John Doe",
          username: "johndoe",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        likes: 0,
        replies: [],
        isLiked: false,
        parentId: null,
      }

      setComments(sortComments([newComment, ...comments], sortBy))
      setCommentText("")
      setIsSubmitting(false)
    }, 1000)
  }

  const handleReply = (commentId: string) => {
    if (replyingTo === commentId) {
      setReplyingTo(null)
    } else {
      setReplyingTo(commentId)
      setReplyText("")
    }
  }

  const submitReply = (parentId: string) => {
    if (!replyText.trim()) return

    // Simulate API call
    setTimeout(() => {
      const newReply = {
        id: `reply-${Date.now()}`,
        content: replyText,
        createdAt: new Date().toISOString(),
        author: {
          id: "user-1",
          name: "John Doe",
          username: "johndoe",
          avatar: "/placeholder.svg?height=40&width=40",
        },
        likes: 0,
        replies: [],
        isLiked: false,
        parentId,
      }

      // Find the parent comment and add the reply
      const updatedComments = [...comments]
      const findAndAddReply = (commentsArray: CommentType[], targetId: string): boolean => {
        for (let i = 0; i < commentsArray.length; i++) {
          if (commentsArray[i].id === targetId) {
            commentsArray[i].replies.unshift(newReply)
            return true
          }
          if (commentsArray[i].replies.length > 0) {
            if (findAndAddReply(commentsArray[i].replies, targetId)) {
              return true
            }
          }
        }
        return false
      }

      findAndAddReply(updatedComments, parentId)
      setComments(updatedComments)
      setReplyingTo(null)
      setReplyText("")

      // Automatically expand the comment that was just replied to
      if (!expandedComments.includes(parentId)) {
        setExpandedComments([...expandedComments, parentId])
      }
    }, 500)
  }

  const toggleLike = (commentId: string) => {
    const updatedComments = [...comments]

    const findAndToggleLike = (commentsArray: CommentType[], targetId: string): boolean => {
      for (let i = 0; i < commentsArray.length; i++) {
        if (commentsArray[i].id === targetId) {
          commentsArray[i].isLiked = !commentsArray[i].isLiked
          commentsArray[i].likes += commentsArray[i].isLiked ? 1 : -1
          return true
        }
        if (commentsArray[i].replies.length > 0) {
          if (findAndToggleLike(commentsArray[i].replies, targetId)) {
            return true
          }
        }
      }
      return false
    }

    findAndToggleLike(updatedComments, commentId)
    setComments(updatedComments)
  }

  const toggleReplies = (commentId: string) => {
    if (expandedComments.includes(commentId)) {
      setExpandedComments(expandedComments.filter((id) => id !== commentId))
    } else {
      setExpandedComments([...expandedComments, commentId])
    }
  }

  const renderComment = (comment: CommentType, depth = 0) => {
    const isExpanded = expandedComments.includes(comment.id)
    const hasReplies = comment.replies.length > 0

    return (
      <div key={comment.id} className={cn("mb-4", depth > 0 && "ml-6")}>
        <Card className={cn(depth > 0 && "border-l-4 border-l-primary/20")}>
          <CardHeader className="flex flex-row items-start space-y-0 pb-2">
            <div className="flex items-center space-x-4">
              <Avatar>
                <AvatarImage src={comment.author.avatar} alt={comment.author.name} />
                <AvatarFallback>{comment.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <div className="flex items-center">
                  <span className="font-semibold">{comment.author.name}</span>
                  <span className="ml-2 text-sm text-muted-foreground">@{comment.author.username}</span>
                  <span className="mx-1 text-muted-foreground">·</span>
                  <span className="text-sm text-muted-foreground">
                    {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                  </span>
                </div>
              </div>
            </div>
            <div className="ml-auto">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Report</DropdownMenuItem>
                  <DropdownMenuItem>Copy text</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="whitespace-pre-line">{comment.content}</p>
          </CardContent>
          <CardFooter className="flex justify-start space-x-4 pt-2">
            <Button
              variant="ghost"
              size="sm"
              className={cn("rounded-full text-muted-foreground", comment.isLiked && "text-red-500")}
              onClick={() => toggleLike(comment.id)}
            >
              <Heart className="mr-1 h-4 w-4" fill={comment.isLiked ? "currentColor" : "none"} />
              {comment.likes}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="rounded-full text-muted-foreground"
              onClick={() => handleReply(comment.id)}
            >
              <Reply className="mr-1 h-4 w-4" />
              Reply
            </Button>
            {hasReplies && (
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full text-muted-foreground"
                onClick={() => toggleReplies(comment.id)}
              >
                {isExpanded ? <ChevronUp className="mr-1 h-4 w-4" /> : <ChevronDown className="mr-1 h-4 w-4" />}
                {comment.replies.length} {comment.replies.length === 1 ? "reply" : "replies"}
              </Button>
            )}
          </CardFooter>
        </Card>

        {replyingTo === comment.id && (
          <div className="ml-6 mt-2">
            <div className="flex space-x-4">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" alt="@user" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <Textarea
                  placeholder={`Reply to @${comment.author.username}...`}
                  className="min-h-[60px] resize-none"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                />
                <div className="mt-2 flex justify-end space-x-2">
                  <Button variant="outline" size="sm" onClick={() => setReplyingTo(null)}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={() => submitReply(comment.id)} disabled={!replyText.trim()}>
                    Reply
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {isExpanded && hasReplies && (
          <div className="mt-2">{comment.replies.map((reply) => renderComment(reply, depth + 1))}</div>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Comments</h3>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  Sort by: {sortBy === "recent" ? "Recent" : "Popular"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleSortChange("recent")}>Recent</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSortChange("popular")}>Popular</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@user" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                placeholder="Add a comment..."
                className="min-h-[80px] resize-none"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSubmit} disabled={!commentText.trim() || isSubmitting}>
            {isSubmitting && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
            Comment
          </Button>
        </CardFooter>
      </Card>

      {loading ? (
        <div className="flex justify-center p-4">
          <Icons.spinner className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : comments.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No comments yet. Be the first to comment!</p>
        </Card>
      ) : (
        <div className="space-y-4">{comments.map((comment) => renderComment(comment))}</div>
      )}
    </div>
  )
}

