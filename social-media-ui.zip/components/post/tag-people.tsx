"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, X, Check } from "lucide-react"

interface TagPeopleProps {
  onTagPeopleSelect: (people: string[]) => void
  initialTags?: string[]
}

export function TagPeople({ onTagPeopleSelect, initialTags = [] }: TagPeopleProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPeople, setSelectedPeople] = useState<string[]>(initialTags)

  // Mock user data
  const mockUsers = [
    { id: "1", name: "Jane Smith", username: "janesmith", avatar: "/placeholder.svg?height=40&width=40" },
    { id: "2", name: "Alex Johnson", username: "alexj", avatar: "/placeholder.svg?height=40&width=40" },
    { id: "3", name: "Sam Wilson", username: "samw", avatar: "/placeholder.svg?height=40&width=40" },
    { id: "4", name: "Taylor Brown", username: "taylorbrown", avatar: "/placeholder.svg?height=40&width=40" },
    { id: "5", name: "Jordan Lee", username: "jordanlee", avatar: "/placeholder.svg?height=40&width=40" },
  ]

  const filteredUsers = searchQuery
    ? mockUsers.filter(
        (user) =>
          user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.username.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : mockUsers

  const toggleUser = (username: string) => {
    if (selectedPeople.includes(username)) {
      setSelectedPeople(selectedPeople.filter((name) => name !== username))
    } else {
      setSelectedPeople([...selectedPeople, username])
    }
  }

  const handleDone = () => {
    onTagPeopleSelect(selectedPeople)
  }

  return (
    <Card className="w-80">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Tag People</CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="relative mb-3">
          <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search people"
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {selectedPeople.length > 0 && (
          <div className="mb-3">
            <p className="mb-1 text-sm font-medium">Selected ({selectedPeople.length})</p>
            <div className="flex flex-wrap gap-1">
              {selectedPeople.map((username, index) => {
                const user = mockUsers.find((u) => u.username === username)
                return (
                  <div key={index} className="flex items-center rounded-full bg-muted px-2 py-1 text-xs">
                    <span>@{username}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="ml-1 h-4 w-4 p-0 rounded-full"
                      onClick={() => toggleUser(username)}
                    >
                      <X className="h-2 w-2" />
                    </Button>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        <div className="max-h-60 overflow-y-auto space-y-1">
          {filteredUsers.map((user) => (
            <button
              key={user.id}
              className="flex w-full items-center justify-between rounded-md px-2 py-1.5 hover:bg-muted"
              onClick={() => toggleUser(user.username)}
            >
              <div className="flex items-center">
                <Avatar className="h-8 w-8 mr-2">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="text-left">
                  <p className="text-sm font-medium">{user.name}</p>
                  <p className="text-xs text-muted-foreground">@{user.username}</p>
                </div>
              </div>
              {selectedPeople.includes(user.username) && <Check className="h-4 w-4 text-primary" />}
            </button>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleDone}>Done</Button>
      </CardFooter>
    </Card>
  )
}

