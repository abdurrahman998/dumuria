"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"

interface EmojiPickerProps {
  onEmojiSelect: (emoji: string) => void
}

export function EmojiPicker({ onEmojiSelect }: EmojiPickerProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("recent")

  // Mock emoji data
  const emojiCategories = {
    recent: ["😀", "😂", "❤️", "👍", "🎉", "🔥", "😊", "👏"],
    smileys: ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘"],
    people: ["👶", "👧", "🧒", "👦", "👩", "🧑", "👨", "👵", "🧓", "👴", "👲", "👳‍♀️", "👳‍♂️", "🧕", "👮‍♀️", "👮‍♂️"],
    animals: ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵"],
    food: ["🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅"],
    activities: ["⚽️", "🏀", "🏈", "⚾️", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏"],
    travel: ["🚗", "🚕", "🚙", "🚌", "🚎", "🏎", "🚓", "🚑", "🚒", "🚐", "🚚", "🚛", "🚜", "🛴", "🚲", "🛵", "🏍"],
    symbols: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟"],
  }

  const filteredEmojis = searchQuery
    ? Object.values(emojiCategories)
        .flat()
        .filter((emoji) => emoji.includes(searchQuery))
    : emojiCategories[activeTab as keyof typeof emojiCategories]

  return (
    <Card className="w-64 max-w-[90vw]">
      <CardHeader className="p-3">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search emoji"
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </CardHeader>
      <Tabs defaultValue="recent" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 h-auto">
          <TabsTrigger value="recent" className="text-xs py-1">
            Recent
          </TabsTrigger>
          <TabsTrigger value="smileys" className="text-xs py-1">
            Smileys
          </TabsTrigger>
          <TabsTrigger value="people" className="text-xs py-1">
            People
          </TabsTrigger>
          <TabsTrigger value="animals" className="text-xs py-1">
            Animals
          </TabsTrigger>
        </TabsList>
        <TabsList className="grid w-full grid-cols-4 h-auto">
          <TabsTrigger value="food" className="text-xs py-1">
            Food
          </TabsTrigger>
          <TabsTrigger value="activities" className="text-xs py-1">
            Activities
          </TabsTrigger>
          <TabsTrigger value="travel" className="text-xs py-1">
            Travel
          </TabsTrigger>
          <TabsTrigger value="symbols" className="text-xs py-1">
            Symbols
          </TabsTrigger>
        </TabsList>

        {Object.keys(emojiCategories).map((category) => (
          <TabsContent key={category} value={category} className="p-0">
            <CardContent className="p-3">
              <div className="grid grid-cols-8 gap-1">
                {(searchQuery ? filteredEmojis : emojiCategories[category as keyof typeof emojiCategories]).map(
                  (emoji, index) => (
                    <button
                      key={index}
                      className="flex h-7 w-7 items-center justify-center rounded-md hover:bg-muted"
                      onClick={() => onEmojiSelect(emoji)}
                    >
                      <span className="text-lg">{emoji}</span>
                    </button>
                  ),
                )}
              </div>
            </CardContent>
          </TabsContent>
        ))}
      </Tabs>
    </Card>
  )
}

