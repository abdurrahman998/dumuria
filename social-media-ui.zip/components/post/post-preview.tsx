"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, Repeat, Share, MapPin, Clock, AtSign } from "lucide-react"
import { cn } from "@/lib/utils"

interface PostPreviewProps {
  content: string
  images?: string[]
  video?: string | null
  gif?: string | null
  audio?: string | null
  location?: string | null
  taggedPeople?: string[]
  feeling?: string | null
  pollOptions?: { options: string[]; duration: string } | null
  background?: string | null
}

export function PostPreview({
  content,
  images = [],
  video = null,
  gif = null,
  audio = null,
  location = null,
  taggedPeople = [],
  feeling = null,
  pollOptions = null,
  background = null,
}: PostPreviewProps) {
  // Format content with markdown-like syntax
  const formatContent = (text: string) => {
    // Replace bold
    let formattedText = text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")

    // Replace italic
    formattedText = formattedText.replace(/\*(.*?)\*/g, "<em>$1</em>")

    // Replace code
    formattedText = formattedText.replace(/`(.*?)`/g, "<code>$1</code>")

    // Replace links
    formattedText = formattedText.replace(
      /\[(.*?)\]$$(.*?)$$/g,
      '<a href="$2" class="text-blue-500 hover:underline">$1</a>',
    )

    // Replace headers
    formattedText = formattedText.replace(/^# (.*?)$/gm, '<h1 class="text-xl font-bold">$1</h1>')
    formattedText = formattedText.replace(/^## (.*?)$/gm, '<h2 class="text-lg font-semibold">$1</h2>')

    // Replace lists
    formattedText = formattedText.replace(/^- (.*?)$/gm, "<li>$1</li>")

    // Replace hashtags
    formattedText = formattedText.replace(/#(\w+)/g, '<span class="text-blue-500">#$1</span>')

    // Replace mentions
    formattedText = formattedText.replace(/@(\w+)/g, '<span class="text-blue-500">@$1</span>')

    // Wrap in paragraphs
    formattedText = formattedText.replace(/^(?!<h1|<h2|<li)(.+)$/gm, "<p>$1</p>")

    return formattedText
  }

  return (
    <Card className={cn("relative overflow-hidden", background && "border-0")}>
      {background && <div className="absolute inset-0 z-0 opacity-20" style={{ backgroundColor: background }} />}

      <CardHeader className="flex flex-row items-start space-y-0 pb-2 relative z-10">
        <div className="flex items-center space-x-4">
          <Avatar>
            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="John Doe" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <div className="flex items-center">
              <span className="font-semibold">John Doe</span>
              <span className="ml-2 text-sm text-muted-foreground">@johndoe</span>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span>Just now</span>

              {feeling && <span>• feeling {feeling}</span>}

              {location && (
                <div className="flex items-center">
                  <MapPin className="mr-1 h-3 w-3" />
                  <span>{location}</span>
                </div>
              )}

              {taggedPeople.length > 0 && (
                <div className="flex items-center">
                  <AtSign className="mr-1 h-3 w-3" />
                  <span>with {taggedPeople.join(", ")}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-2 relative z-10">
        <div className="whitespace-pre-line" dangerouslySetInnerHTML={{ __html: formatContent(content) }} />

        {/* Media preview section */}
        <div className="mt-3 space-y-3">
          {/* Images preview */}
          {images.length > 0 && (
            <div
              className={cn(
                "grid gap-2",
                images.length === 1
                  ? "grid-cols-1"
                  : images.length === 2
                    ? "grid-cols-2"
                    : images.length === 3
                      ? "grid-cols-2"
                      : "grid-cols-2",
              )}
            >
              {images.map((image, index) => (
                <div key={index} className="rounded-lg overflow-hidden">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`Preview ${index + 1}`}
                    className="w-full h-auto object-cover"
                    style={{ maxHeight: "300px" }}
                  />
                </div>
              ))}
            </div>
          )}

          {/* Video preview */}
          {video && (
            <div className="rounded-lg overflow-hidden">
              <video src={video} controls className="w-full h-auto" style={{ maxHeight: "300px" }} />
            </div>
          )}

          {/* GIF preview */}
          {gif && (
            <div className="rounded-lg overflow-hidden">
              <img
                src={gif || "/placeholder.svg"}
                alt="GIF"
                className="w-full h-auto object-cover"
                style={{ maxHeight: "300px" }}
              />
            </div>
          )}

          {/* Audio preview */}
          {audio && (
            <div className="rounded-lg overflow-hidden bg-muted p-3">
              <audio src={audio} controls className="w-full" />
            </div>
          )}

          {/* Poll preview */}
          {pollOptions && (
            <div className="rounded-lg border p-3">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">Poll</h4>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="mr-1 h-3 w-3" />
                  <span>Duration: {pollOptions.duration}</span>
                </div>
              </div>
              <div className="space-y-2">
                {pollOptions.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div className="h-4 w-4 rounded-full border border-primary"></div>
                    <span>{option}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="flex justify-between pt-2 relative z-10">
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <MessageCircle className="mr-1 h-4 w-4" />0
        </Button>
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <Repeat className="mr-1 h-4 w-4" />0
        </Button>
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <Heart className="mr-1 h-4 w-4" />0
        </Button>
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground">
          <Share className="mr-1 h-4 w-4" />
          Share
        </Button>
      </CardFooter>
    </Card>
  )
}

